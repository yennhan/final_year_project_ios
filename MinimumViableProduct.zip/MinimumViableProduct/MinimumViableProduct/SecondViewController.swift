//
//  SecondViewController.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 17/07/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    var sideMenuOpen = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name("toggleSideMenu"), object: nil)
        // Do any additional setup after loading the view.
    }

    @objc func toggleSideMenu(){
        if sideMenuOpen{
            sideMenuOpen = false
            sideMenuConstraint?.constant = -250
        }else{
            sideMenuOpen = true
            sideMenuConstraint?.constant = 0
        }
        UIView.animate(withDuration: 0.3){
            self.view.layoutIfNeeded()
        }

    }
   
}
