//
//  ThirdViewController.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 17/09/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit
import AVFoundation
import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
import SDWebImage
        
protocol CellDelegate{
    func didTapCell(index: Int)
}
class ThirdViewController: UIViewController,AVAudioRecorderDelegate,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var myTableView: UITableView!
    
    let rootRef = Database.database().reference()
    var recordSession:AVAudioSession!
    var audioRecorder:AVAudioRecorder!
    var audioPlayer:AVAudioPlayer!
    var audioReference: StorageReference {
        return Storage.storage().reference().child("audio")
    }
    var numberOfRecords:Int = 0

    @IBOutlet weak var recordbutton: UIButton!
    
    @IBAction func recording(_ sender: Any)
    {
        //Check if recording is recording
        if audioRecorder == nil
        {
            numberOfRecords += 1
            let filename = getDirectory().appendingPathComponent("\(numberOfRecords).m4a")
            
            let settings = [AVFormatIDKey: Int(kAudioFormatMPEG4AAC),AVSampleRateKey: 12000, AVNumberOfChannelsKey: 1, AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue]
            
            //start audio recording
            do
            {
                audioRecorder = try AVAudioRecorder(url: filename, settings: settings)
                audioRecorder.delegate = self
                audioRecorder.record()
                recordbutton.setTitle("Stop Recording", for: .normal)
            }
            catch
            {
                displayAlert(title: "Ops!", message: "Recording failed")
            }
        }
        else
        {
            //Stop audio recording session
            audioRecorder.stop()
            audioRecorder = nil
            
            UserDefaults.standard.set(numberOfRecords, forKey:"MyNumber")
            myTableView.reloadData()
            recordbutton.setTitle("Start Recording", for: .normal)
        }
    }
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var strangerView: UIImageView!
    @IBOutlet weak var Count: UILabel!
    var image = UIImage()
    var label = ""
    var stranger_label = ""
    var counting = ""
    //cell.imageView.sd_setImage(with: URL(string: image.url), placeholderImage: UIImage(named: "avatar-1"))
    override func viewDidLoad() {
        super.viewDidLoad()
        strangerView.sd_setImage(with: URL(string: stranger_label), placeholderImage: UIImage(named: "avatar-1"))
       ImageView.sd_setImage(with: URL(string: label), placeholderImage: UIImage(named: "avatar-1"))
        Count.text=counting
        print(counting)
        recordSession = AVAudioSession.sharedInstance()
        if let number:Int = UserDefaults.standard.object(forKey: "MyNumber") as? Int
        {
            numberOfRecords = number
        }
        
        AVAudioSession.sharedInstance().requestRecordPermission { (hasPermission) in
            if hasPermission
            {
                print("ACCEPTED ")
            }
        }
    }
    var thevariable = ""
   
    @IBAction func UploadRecord(_ sender: Any)
    {
        let path = getDirectory().appendingPathComponent("\(thevariable).m4a")
        let uploadsoundRef = audioReference.child(thevariable)
        
        print("Hi")
        let uploadTask = uploadsoundRef.putFile(from: path, metadata: nil) { (metadata, error ) in
            if (error != nil)
            {
                print("Upload Error")
            }else {
                print(metadata ?? "No metadata")
                print(error ?? "No Error")
                uploadsoundRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        // Uh-oh, an error occurred!
                        return
                    }
                    print("\(downloadURL)")
                    self.update_database(the_url:downloadURL)
                }
            }
           
        }
        uploadTask.observe(.progress){ (snapshot) in
            print(snapshot.progress ?? "NO MORE PROGRESS")
            
        }
        uploadsoundRef.downloadURL { (url, error) in
            guard let downloadURL = url else {
                // Uh-oh, an error occurred!
                return
            }
            print("\(downloadURL)")
        }
        
        uploadTask.resume()
    }
        /*let fileUrl = path
        let storage = Storage.storage()
        let metadata = StorageMetadata()
        
        metadata.contentType = "audio/mp4"
        let refStr = (Auth.auth().currentUser?.email)! + "|" + "\(NSUUID().uuidString)" + "|" + "recording.m4a"
        let pathStr = "Messages/\(NSUUID().uuidString)/\(refStr)"
        let uploadRef = storage.reference().child(pathStr)
        uploadRef.putFile(from: fileUrl, metadata: nil) { metadata,
            error in
            if error == nil {
                print("Successfully Uploaded Audio")
                let downloadUrl = fileUrl
                print("URL: \(downloadUrl)")
                
                var messageInfoArray = refStr.components(separatedBy: "|")
                let messageDict = ["Sender": messageInfoArray[0], "MessageBody": "recording-audioRecorded", "AudioURL": "\(pathStr)", "AudioID": messageInfoArray[1], "IsAudio": "\(NSUUID().uuidString)-True"]
                
                let childUpdates = ["Mensagens/\(messageInfoArray[1])": messageDict]
                Database.database().reference().updateChildValues(childUpdates)
            }
        }*/
    
    
    //Function that displays alert.
    func displayAlert(title:String, message:String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    //Function that gets path todirectory
    func getDirectory() -> URL
    {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = paths[0]
        return documentDirectory
    }
    override func didReceiveMemoryWarning() {
    }
    func update_database(the_url:URL){
        rootRef.child("audio_file").childByAutoId().setValue("\(the_url)")
    }
    //setting up table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfRecords
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let path = getDirectory().appendingPathComponent("\(indexPath.row + 1).m4a")
        let fileName = URL(fileURLWithPath: path.absoluteString).deletingPathExtension().lastPathComponent
        cell.textLabel?.text = fileName
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let path = getDirectory().appendingPathComponent("\(indexPath.row + 1).m4a")
        let fileName = URL(fileURLWithPath: path.absoluteString).deletingPathExtension().lastPathComponent
        getAudioFileURL(msg:fileName)
        do
        {
            audioPlayer = try AVAudioPlayer(contentsOf: path)
            audioPlayer.play()
            try recordSession.overrideOutputAudioPort(AVAudioSessionPortOverride.speaker)
           
        }
        catch
        {
            
        }
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let path = getDirectory().appendingPathComponent("Recording\(indexPath.row + 1).m4a")
        if editingStyle == .delete {
            do{
                print("test", indexPath)
                try? FileManager.default.removeItem(at: path)
                numberOfRecords -= 1
                tableView.deleteRows(at: [indexPath], with: .automatic)
                UserDefaults.standard.set(numberOfRecords, forKey: "MyNumber")
            }
            /*catch
            {
                displayAlert(title: "OOPS", message: "Delete failed")
            }*/
        }
    }
    
    func getAudioFileURL(msg:String) {
        self.thevariable = msg
        
        
        /*return getDirectory().appendingPathComponent(".m4a")
        */
    }
    
}

