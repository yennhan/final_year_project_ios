//
//  TheImage.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 15/09/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import Foundation
import FirebaseDatabase
struct TheImage {
    let key: String!
    let url: String!
    
    let itemref: DatabaseReference?
    
    init(url:String, key:String){
        self.key = key
        self.url = url
        self.itemref = nil
    }
    init(snapshot:DataSnapshot)
    {
        key = snapshot.key
        itemref = snapshot.ref
        
        let snapshotValue = snapshot.value as? NSDictionary
        
        if let imageUrl = snapshotValue?["url"] as? String {
            url = imageUrl
        }else {
            url = ""
        }
    }
}
