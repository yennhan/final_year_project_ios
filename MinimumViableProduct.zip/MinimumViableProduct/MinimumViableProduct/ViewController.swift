//
//  ViewController.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 17/07/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import AVFoundation

class ViewController: UIViewController{



    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
//signIn for user
    @IBOutlet weak var signInUsername: UITextField!
    @IBOutlet weak var signInPassword: UITextField!

    
    //signUp for user
    @IBOutlet weak var signUpUsername: UITextField!
    @IBOutlet weak var signUpEmail: UITextField!
    @IBOutlet weak var signUpPassword: UITextField!

    @IBOutlet weak var draw: DrawView!


    @IBAction func erase(_ sender: UIButton) {
        draw.erase()
    }
    
    @IBAction func isAgree(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
    @IBAction func signUpButton(_ sender: Any) {
        if let email=signUpEmail.text, let password=signUpPassword.text
        {
            Auth.auth().createUser(withEmail: email, password: password) { (user,error ) in
                if user != nil {
                    //user is found, go to home screen
                    self.performSegue(withIdentifier: "goToHome", sender: self)
                }
                else{
                    //check error
                }
            }
        }
        
    }
    
    @IBAction func signInButton(_ sender: Any) {
        
        //TODO: Do some validation on emails and password
        if let email=signInUsername.text, let password=signInPassword.text
        {
            Auth.auth().signIn(withEmail: email, password: password) { (user,error ) in
                //check user is not nil
                if user != nil {
                    //user is not found, go to home screen
                    self.performSegue(withIdentifier: "goToHome", sender: self)
                }
                else{
                    //check error
                }
            }
        }
        
    }
    
}

