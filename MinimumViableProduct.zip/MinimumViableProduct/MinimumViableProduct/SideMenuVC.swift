//
//  SideMenuVC.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 17/07/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit

class SideMenuVC: UITableViewController {

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(indexPath.row)
        NotificationCenter.default.post(name: NSNotification.Name("toggleSideMenu"),object:nil)
        switch indexPath.row {
        case 0: NotificationCenter.default.post(name: NSNotification.Name("showProfile"),object:nil)
        case 1: NotificationCenter.default.post(name: NSNotification.Name("showSignOut"),object:nil)
        
        default: break
        }
    }

}

