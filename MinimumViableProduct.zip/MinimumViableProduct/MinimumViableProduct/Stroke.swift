//
//  Stroke.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 20/07/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit

struct Stroke{
    let startPoint: CGPoint
    let endPoint: CGPoint
    let color: CGColor
}
