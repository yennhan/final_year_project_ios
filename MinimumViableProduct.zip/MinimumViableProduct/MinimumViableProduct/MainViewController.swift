//
//  MainViewController.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 17/07/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//AVAudioRecorderDelegate
//

import UIKit
import AVFoundation
import Firebase
import FirebaseAuth
import FirebaseDatabase
import SDWebImage
class MainViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate, AVAudioRecorderDelegate{

    var images = [TheImage]()
    var stranger = [stranger_pic]()
    var customImageFlowLayout: CustomImageFlowLayout!
    
    var dbREF: DatabaseReference!
    @IBOutlet weak var warning: UIView!
    
    @IBOutlet weak var recordbutton: UIButton!
    @IBOutlet weak var imageCollection: UICollectionView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        Database.database().isPersistenceEnabled = false
        dbREF = Database.database().reference().child("users_images")
        loadDB()

        /*customImageFlowLayout = CustomImageFlowLayout()
        imageCollection.collectionViewLayout = customImageFlowLayout
        imageCollection.backgroundColor = .white */
        NotificationCenter.default.addObserver(self, selector: #selector(showProfile), name: NSNotification.Name("showProfile"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showSignOut), name: NSNotification.Name("showSignOut"), object: nil)
    self.warning.alpha = 0.0
    blinkAnimation()
        //Setting Up Session

    }
    
    func loadDB(){
        
        dbREF.queryOrdered(byChild: "time").observe(DataEventType.value, with: {(snapshot) in
            var newImages = [TheImage]()
            var newStranger = [stranger_pic]()
            for imagesSnapshot in snapshot.children{
                let theobject = TheImage(snapshot: imagesSnapshot as! DataSnapshot)
                //newImages.append(theobject)
                let thestranger = stranger_pic(snapshot: imagesSnapshot as! DataSnapshot)
                //let theCount = count_faces(snapshot: imagesSnapshot as! DataSnapshot)
                //newCount_Face.insert(theCount, at: 0)
                newImages.insert(theobject, at: 0)
                newStranger.insert(thestranger, at:0)
                
            }
            self.images = newImages
            self.stranger = newStranger
            //self.counting_face = newCount_Face
            
        self.imageCollection.reloadData()
    })
    }
    

    
    @objc func showProfile(){
        performSegue(withIdentifier: "showProfile", sender: nil)
    }
    @objc func showSignOut(){
         performSegue(withIdentifier: "showSignOut", sender: nil)
    }
    @IBAction func onMoreTapped(){
        //print("Toggle side menu")
        NotificationCenter.default.post(name: NSNotification.Name("toggleSideMenu"),object:nil)
    }
    
    func blinkAnimation() {
        if self.warning.alpha == 0.0 {
            //show us view with fade in fade out
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                UIView.setAnimationRepeatCount(100)
               self.warning.alpha = 1.0
            })
            
        }else{
            UIView.animate(withDuration: 1.5, delay: 0.2, options: .curveEaseOut, animations: {
                UIView.setAnimationRepeatCount(100)
                self.warning.alpha = 0.0
            })
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    @IBOutlet weak var timePosted: UILabel!
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = imageCollection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ImageCollectionViewCell
        //let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        let image = images[indexPath.row]
        
        cell.imageView.sd_setImage(with: URL(string: image.url), placeholderImage: UIImage(named: "avatar-1"))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let mainStoryboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let desVC = mainStoryboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        let image = images[indexPath.row]
        let strang = stranger[indexPath.row]
        desVC.label =  image.url
        desVC.stranger_label = strang.url
        self.navigationController?.pushViewController(desVC, animated: true)
    }
    
    
}
