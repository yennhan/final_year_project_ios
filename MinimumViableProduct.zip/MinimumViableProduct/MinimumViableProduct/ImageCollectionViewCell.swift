//
//  ImageCollectionViewCell.swift
//  MinimumViableProduct
//
//  Created by Leow Yenn Han on 14/09/2018.
//  Copyright © 2018 Leow Yenn Han. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func prepareForReuse() {   
        super.prepareForReuse()
        self.imageView.image = nil
    }
}
